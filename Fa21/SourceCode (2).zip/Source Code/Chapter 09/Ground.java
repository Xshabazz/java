public class Ground
{
     public Ground()
     {
          System.out.println("You are on the ground.");
     }

     public Ground(String groundColor)
     {
          System.out.println("The ground is "
                             + groundColor);
     }
}
