interface IntCalculator
{
   int calculate(int number);
}