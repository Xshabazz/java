public class Shape
{
     private double area;

     public void setArea(double a)
     {
          area = a;
     }

     public double getArea()
     {
          return area;
     }
};

