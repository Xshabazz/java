public class ClassB extends ClassA
{
     public void showMe(int x)
     {
          System.out.println("CLASS B: " + x);
     }
}
