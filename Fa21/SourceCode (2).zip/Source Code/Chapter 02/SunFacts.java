// This program uses E notation.

public class SunFacts
{
   public static void main(String[] args)
   {
      double distance, mass;

      distance = 1.495979E11;
      mass = 1.989E30;
      System.out.print("The Sun is " + distance);
      System.out.println(" meters away.");
      System.out.print("The Sun's mass is " + mass);
      System.out.println(" kilograms.");
   }
}
