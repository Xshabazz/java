// An unruly printing program

public class Unruly
{
   public static void main(String[] args)
   {
      System.out.print("These are our top sellers:");
      System.out.print("Computer games");
      System.out.print("Coffee");
      System.out.println("Aspirin");
   }
}