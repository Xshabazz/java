/**
 * This class overloads the square method.
 */

public class MyMath
{
   public static int square(int number)
   {
      return number * number;
   }

   public static double square(double number)
   {
      return number * number;
   }
}

