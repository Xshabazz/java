/**
 * CarType enumerated data type
 */

enum CarType { PORSCHE, FERRARI, JAGUAR }