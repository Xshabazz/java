/**
 * This class demonstrates the Recursive.message method.
 */

public class RecursionDemo
{
   public static void main(String[] args)
   {
      Recursive.message(5);
   }
}
